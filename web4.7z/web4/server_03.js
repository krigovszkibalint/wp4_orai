var http = require('http');
const { randomInt } = require('node:crypto');
var url  = require('url');

http.createServer(

    function (request, response)
    {
        response.writeHead(404, {'Content-Type': 'text/html' });
        var ora = randomInt(1,25);
        if (0 <= ora < 10)
         response.end('<h1>Reggel</h1>'+ ora);
        else if (10 < ora < 12)
         response.end('<h1>Délelőtt</h1>'+ ora);
        else if (ora == 12)
         response.end('<h1>Dél</h1>'+ ora);
        else if (12 < ora <= 18)
         response.end('<h1>Délután</h1>'+ ora);
        else if(19 < ora < 0)
         response.end('<h1>Este</h1>'+ ora);
    }
).listen(8880);