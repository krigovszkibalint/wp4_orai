var http = require('http');
var url  = require('url');
http.createServer(

    function (request, response)
    {
        response.writeHead(404, {'Content-Type': 'text/html' });
        //response.end(request.url);
        var queryString = url.parse(request.url, true).query;
        response.end(queryString.neptun)
    }
).listen(8880);