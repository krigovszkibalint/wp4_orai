var express = require("express");
var application = express();

application.get('/', 
function (request, response)
{
    response.send("Hello World!");
});

var server = application.listen(8080, function(){
    var host = server.address().address;
    var port = server.address().port;

    console.log("Server host: "+host+" port: "+port);
})