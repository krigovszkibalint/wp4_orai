
var express = require("express");
var application = express();

/*employees*/

application.get('/employees', function(request, response)
{
    //response.send('GET-es kérés');
    //response.send(request.query.name);
    json = {
        neptun: 'KDPEQ8',
        szoba: '023',
        mellek: 4137
    };
    response.end(JSON.stringify(json));
});
application.post('/employees', function(request, response)
{
    //response.send('POST-os kérés');

});
application.put('/employees', function(request, response)
{
    response.send('PUT-os kérés');
});
application.delete('/employees', function(request, response)
{
    response.send('DELETE-es kérés');
});

var server = application.listen(8080, function(){});