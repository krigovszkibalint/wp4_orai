var http = require('http');
http.createServer(
    function (request, response)
    {
        response.writeHead(404, {'Content-Type': 'text/html' });
        response.end('<h1>sziauram</h1>');
    }
).listen(8080);